//
//  HeroVideoTableViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//


#import "HeroVideoTableViewController.h"
#import "heroVideoViewModel.h"

#import "allHeroesNetManager.h"

#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

/** HeroVideoCell */
@interface HeroVideoCell : UITableViewCell
@property (nonatomic , strong) UIImageView *coverIV;
@property (nonatomic , strong) UILabel *titleLB;
@property (nonatomic , strong) UILabel *timeLB;
@end

@implementation HeroVideoCell
- (UIImageView *)coverIV {
    if (!_coverIV) {
        _coverIV = [[UIImageView alloc]init];
    }
    return _coverIV;
}
- (UILabel *)titleLB {
    if (!_titleLB) {
        _titleLB = [[UILabel alloc]init];
        _titleLB.font = [UIFont systemFontOfSize:14];
        _titleLB.numberOfLines = 0;
    }
    return _titleLB;
}
- (UILabel *)timeLB {
    if (!_timeLB) {
        _timeLB = [[UILabel alloc]init];
        _timeLB.font = [UIFont systemFontOfSize:12];
        _timeLB.textColor = [UIColor lightGrayColor];
    }
    return _timeLB;
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.coverIV];
        [self.contentView addSubview:self.titleLB];
        [self.contentView addSubview:self.timeLB];
        
        [self.coverIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(0);
            make.left.mas_equalTo(15);
            make.size.mas_equalTo(CGSizeMake(100, 60));
        }];
        [self.titleLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(15);
            make.left.mas_equalTo(_coverIV.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-20);
        }];
        [self.timeLB mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(-15);
            make.bottom.mas_equalTo(-5);
        }];
    }
    return self;
}
@end

/** HeroVideoTableViewController */
@interface HeroVideoTableViewController ()
@property (nonatomic , strong) heroVideoViewModel *HeroVideoVM;

@end

@implementation HeroVideoTableViewController

- (heroVideoViewModel *)HeroVideoVM {
    if (!_HeroVideoVM) {
        _HeroVideoVM = [[heroVideoViewModel alloc]initWithEnName:_enName];
    }
    return _HeroVideoVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[HeroVideoCell class] forCellReuseIdentifier:@"cell"];
    
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.HeroVideoVM refreshDataCompletionHandle:^(NSError *error) {
           [self.tableView.header endRefreshing];
           [self.tableView reloadData];
       }];
    }];
    [self.tableView.header beginRefreshing];
    self.tableView.footer = [MJRefreshBackGifFooter footerWithRefreshingBlock:^{
        [self.HeroVideoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView.footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.HeroVideoVM.rowNumber;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    HeroVideoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    [cell.coverIV setImageWithURL:[self.HeroVideoVM coverURLForRow:indexPath.row] placeholderImage:[UIImage imageNamed:@"about_bad_feel"]];
    
    cell.titleLB.text = [self.HeroVideoVM titlrForRow:indexPath.row];
    cell.timeLB.text = [self.HeroVideoVM uploadTimeForRow:indexPath.row];
    cell.backgroundColor = [UIColor colorWithWhite:1 alpha:0.9];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=f&vid=185466
    NSString *str = [self.HeroVideoVM vidForRow:indexPath.row];
    [allHeroesNetManager getVideoVid:str Completionhandle:^(videoModel *model, NSError *error) {
        NSArray *path = model.result.items.A350.transcode.urls;
        NSString *VideoStr = path[0];
        AVPlayerViewController *vc = [[AVPlayerViewController alloc]init];
        vc.player = [AVPlayer playerWithURL:[NSURL URLWithString:VideoStr]];
        [self presentViewController:vc animated:YES completion:nil];
        NSLog(@"%@",VideoStr);
    }];
    
    NSLog(@"%@",str);
    
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"HeroVideoTableViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"HeroVideoTableViewController"];
}

@end

//
//  heroesViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "heroesViewController.h"
#import "allHeroesViewModel.h"

#import "HeroVideoTableViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"



@interface heroesViewController ()<UICollectionViewDelegateFlowLayout>

@property (nonatomic , strong) allHeroesViewModel *heroesVM;

@end

@implementation heroesViewController

- (allHeroesViewModel *)heroesVM {
    if (!_heroesVM) {
        _heroesVM = [[allHeroesViewModel alloc]init];
    }
    return _heroesVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.heroesVM refreshDataCompletionHandle:^(NSError *error) {
            [self.collectionView reloadData];
            [self.collectionView.header endRefreshing];
        }];
    }];
    [self.collectionView.header beginRefreshing];
    
    // Do any additional setup after loading the view.
}

#pragma mark <UICollectionViewDataSource>


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.heroesVM.rowNumber;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
    [imageView setImageWithURL:[self.heroesVM iconURLForRow:indexPath.row]];
    
    
    UILabel *label = (UILabel *)[cell viewWithTag:20];
    label.font = [UIFont systemFontOfSize:11];
    label.text = [self.heroesVM nameForRow:indexPath.row];
    
    imageView.layer.cornerRadius = ((kWindowW - 5*20) / 4)/ 2.0 ;
    imageView.layer.masksToBounds = YES;
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    HeroVideoTableViewController *heroVideoVC = [[HeroVideoTableViewController alloc]init];
    heroVideoVC.enName = [self.heroesVM enNameForRow:indexPath.row];
    heroVideoVC.title = [self.heroesVM nameForRow:indexPath.row];
    [self.navigationController pushViewController:heroVideoVC animated:YES];
    
    NSString *CNname = [self.heroesVM nameForRow:indexPath.row];
    NSString *ENName = [self.heroesVM enNameForRow:indexPath.row];
    NSLog(@"%@-%@",CNname,ENName);
}

#pragma mark -- UICollectionViewDelegateFlowLayout
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 20, 10, 20);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat width = (self.view.bounds.size.width - 5*20) / 4;
    CGFloat heigth = width * 195 / 140;
    
    return CGSizeMake(width, heigth);
}

// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"heroesViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"heroesViewController"];
}

@end

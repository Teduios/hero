//
//  LOLBookDataViewController.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LOLBookDataViewController : UIViewController

- (id)initWithRequest : (NSURLRequest *)request;
@property (nonatomic , strong) NSURLRequest *request;

@end

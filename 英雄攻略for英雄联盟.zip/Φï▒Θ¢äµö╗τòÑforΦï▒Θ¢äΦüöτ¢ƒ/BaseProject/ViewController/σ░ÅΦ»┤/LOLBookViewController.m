//
//  LOLBookViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LOLBookViewController.h"
#import "LOLBookDataViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface LOLBookViewController ()<UIWebViewDelegate>
@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation LOLBookViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *bookPath = @"http://m.ouj.com/box?channel=baike";
    self.webView.delegate = self;
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:bookPath]]];
}

#pragma mark -- web delegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSString *bookPath = @"http://m.ouj.com/box?channel=baike";
    if (![request.URL.absoluteString isEqualToString:bookPath]) {
        LOLBookDataViewController *data = [[LOLBookDataViewController alloc]initWithRequest:request];
        [self.navigationController pushViewController:data animated:YES];
        return NO;
    }
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self hideProgress];
}


// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"LOLBookViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"LOLBookViewController"];
}

@end

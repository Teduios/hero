//
//  LOLBookDataViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "LOLBookDataViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface LOLBookDataViewController ()<UIWebViewDelegate>

@property (nonatomic , strong) UIWebView *webView;

@end

@implementation LOLBookDataViewController

- (UIWebView *)webView {
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self;
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _webView;
}

- (id)initWithRequest:(NSURLRequest *)request {
    if (self = [super init]) {
        self.request = request;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title = @"偶家中文网";
    [self.webView loadRequest:_request];
}

#pragma mark -- web delegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    if (navigationType != 5) {
        LOLBookDataViewController *data = [[LOLBookDataViewController alloc]initWithRequest:request];
        [self.navigationController pushViewController:data animated:YES];
    }
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self hideProgress];
}


// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"LOLBookDataViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"LOLBookDataViewController"];
}


@end

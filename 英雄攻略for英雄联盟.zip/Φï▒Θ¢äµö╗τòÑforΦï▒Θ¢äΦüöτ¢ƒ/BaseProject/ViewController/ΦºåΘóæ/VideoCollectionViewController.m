//
//  VideoCollectionViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "VideoCollectionViewController.h"
#import "newVideoViewModel.h"

#import "NewVideoNetManager.h"

#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface VideoCollectionViewController ()<UICollectionViewDelegateFlowLayout>
@property (nonatomic , strong) newVideoViewModel *videoVM;
@end

@implementation VideoCollectionViewController

- (newVideoViewModel *)videoVM {
    if (!_videoVM) {
        _videoVM = [[newVideoViewModel alloc]init];
    }
    return _videoVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.collectionView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.videoVM refreshDataCompletionHandle:^(NSError *error) {
           [self.collectionView reloadData];
           [self.collectionView.header endRefreshing];
       }];
    }];
    
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer = [MJRefreshBackGifFooter footerWithRefreshingBlock:^{
        [self.videoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView.footer endRefreshing];
            [self.collectionView reloadData];
        }];
    }];
    
}

#pragma mark -- UICollectionViewDelegateFlowLayout
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(10, 20, 10, 20);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 10;
}
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat width = kWindowW - 40;
    CGFloat heigth = kWindowW * 0.7;
    
    return CGSizeMake(width, heigth);
}

#pragma mark <UICollectionViewDataSource>


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {

    return self.videoVM.rowNumber;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"videoCell" forIndexPath:indexPath];
    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:300];
    UILabel *titleLB = (UILabel *)[cell viewWithTag:100];
    UILabel *readLB = (UILabel *)[cell viewWithTag:200];
    
    titleLB.text = [self.videoVM titleForRow:indexPath.row];
    readLB.text = [NSString stringWithFormat:@"%@阅读",[self.videoVM readCountForRow:indexPath.row]];
    [imageView setImageWithURL:[self.videoVM srcPhotoForRow:indexPath.row]];
  
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    // http://mw2.dwstatic.com/8/5/1547/189973-99-1447765437.mp4
    
    NSString *artId = [self.videoVM artIdForRow:indexPath.row];
    
    NSMutableArray *dataArr = [[NSMutableArray alloc]init];
    [NewVideoNetManager getNewVideoNewsId:artId Completionhandle:^(NewVideosldModel *model, NSError *error) {
        [dataArr addObjectsFromArray:model.data.video];
        VideoModel *obj = dataArr.firstObject;
        NSString *vid = obj.vid;
        [NewVideoNetManager getVideoLookVid:vid Completionhandle:^(videoLookModel *model, NSError *error) {
            NSArray *videoArr = model.result.items.V1000.transcode.urls;
            NSString *videoStr = videoArr[0];
            
            AVPlayerViewController *vc = [[AVPlayerViewController alloc]init];
            vc.player = [AVPlayer playerWithURL:[NSURL URLWithString:videoStr]];
            [self presentViewController:vc animated:YES completion:nil];
            
            NSLog(@"vid = %@",videoStr);
        }];
    }];
    
}

#pragma mark <UICollectionViewDelegate>

/*
// Uncomment this method to specify if the specified item should be highlighted during tracking
- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath {
	return YES;
}
*/

/*
// Uncomment this method to specify if the specified item should be selected
- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
*/

/*
// Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
- (BOOL)collectionView:(UICollectionView *)collectionView shouldShowMenuForItemAtIndexPath:(NSIndexPath *)indexPath {
	return NO;
}

- (BOOL)collectionView:(UICollectionView *)collectionView canPerformAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	return NO;
}

- (void)collectionView:(UICollectionView *)collectionView performAction:(SEL)action forItemAtIndexPath:(NSIndexPath *)indexPath withSender:(id)sender {
	
}
*/

// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"VideoCollectionViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"VideoCollectionViewController"];
}

@end

//
//  NewViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewViewController.h"
#import "NewViewModel.h"

#import "NewDataViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface NewViewController ()<UITableViewDataSource , UITableViewDelegate>
@property (nonatomic , strong) NewViewModel *NewVM;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation NewViewController

- (NewViewModel *)NewVM {
    if (!_NewVM) {
        _NewVM = [[NewViewModel alloc]init];
    }
    return _NewVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       [self.NewVM refreshDataCompletionHandle:^(NSError *error) {
           [self.tableView reloadData];
           [self.tableView.header endRefreshing];
       }];
    }];
    [self.tableView.header beginRefreshing];
    self.tableView.footer = [MJRefreshBackGifFooter footerWithRefreshingBlock:^{
        [self.NewVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.footer endRefreshing];
        }];
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self.NewVM hasVideoForRow:indexPath.row] == 0) {
        return 80;
    }
    return 0;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.NewVM.rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    
    if ([self.NewVM hasVideoForRow:indexPath.row] == 0) {
        UIImageView *imageView = (UIImageView *)[cell viewWithTag:10];
        [imageView setImageWithURL:[self.NewVM srcPhotoForRow:indexPath.row]];
        
        UILabel *title = (UILabel *)[cell viewWithTag:20];
        title.text = [self.NewVM titleForRow:indexPath.row];
        
        UILabel *content = (UILabel *)[cell viewWithTag:30];
        content.text = [self.NewVM contentForRow:indexPath.row];
        
        UILabel *readCount = (UILabel *)[cell viewWithTag:40];
        readCount.text = [NSString stringWithFormat:@"%@阅读",[self.NewVM readCountForRow:indexPath.row]];
    }
    else {
        cell.hidden = YES;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NewDataViewController *dataVC = [[NewDataViewController alloc]init];
    dataVC.artId = [self.NewVM artidForRow:indexPath.row];
    [self.navigationController pushViewController:dataVC animated:YES];
    
    NSLog(@"%@",dataVC.artId);
}

// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"NewViewController"];
    self.tabBarController.tabBar.hidden = NO;
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"NewViewController"];
}


@end

//
//  NewDataViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewDataViewController.h"
#import "NewNetManager.h"
#import "NewViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface NewDataViewController ()<UIWebViewDelegate>
@property (nonatomic , strong) UIWebView *webView;
@end

@implementation NewDataViewController

- (UIWebView *)webView {
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self;
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _webView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [NewNetManager getnewWithNewsId:self.artId Completionhandle:^(newDataModel *model, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *html_str = model.data.content;
            [self.webView loadHTMLString:html_str baseURL:nil];
        });
        self.title = model.data.title;
    }];
}

#pragma mark -- web delegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self hideProgress];
}


// 统计用户进入此界面的时长和频率
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"NewDataViewController"];
    self.tabBarController.tabBar.hidden = YES;
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"NewDataViewController"];
}


@end

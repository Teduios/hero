//
//  seekDataViewController.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "seekDataViewController.h"

#import "MobClick.h"
#import "MobClickSocialAnalytics.h"

@interface seekDataViewController ()<UIWebViewDelegate>
@property (nonatomic , strong) UIWebView *webView;
@end

@implementation seekDataViewController

- (UIWebView *)webView {
    if (!_webView) {
        _webView = [[UIWebView alloc]init];
        _webView.delegate = self;
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    return _webView;
}


- (id)initWithRequest:(NSURLRequest *)request {
    if (self = [super init]) {
        self.request = request;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.webView loadRequest:self.request];
}

#pragma mark -- web delegat
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    if (navigationType != 5) {
        seekDataViewController *data = [[seekDataViewController alloc]initWithRequest:request];
        [self.navigationController pushViewController:data animated:YES];
        return NO;
    }
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self showProgress];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self hideProgress];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"seekDataViewController"];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"seekDataViewController"];
}


@end

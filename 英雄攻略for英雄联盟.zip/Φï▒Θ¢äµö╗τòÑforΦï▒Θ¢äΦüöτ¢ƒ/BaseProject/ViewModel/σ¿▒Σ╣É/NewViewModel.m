//
//  NewViewModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewViewModel.h"

@implementation NewViewModel

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (DataModel *)modelDataForRow : (NSInteger)row {
    return self.dataArr[row];
}
- (NSURL *)srcPhotoForRow : (NSInteger)row {
    NSString *icon = [self modelDataForRow:row].srcPhoto;
    return [NSURL URLWithString:icon];
} // 图片
- (NSString *)titleForRow : (NSInteger)row {
    return [self modelDataForRow:row].title;
} // 标题
- (NSString *)contentForRow : (NSInteger)row {
    return [self modelDataForRow:row].content;
} // 详情
- (NSString *)readCountForRow : (NSInteger)row {
    return [self modelDataForRow:row].readCount;
} // 阅读人数
- (NSString *)artidForRow:(NSInteger)row {
    return [self modelDataForRow:row].artId;
}
- (NSInteger)hasVideoForRow : (NSInteger)row {
    return [self modelDataForRow:row].hasVideo;
}
//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle {
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle {
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle {
    self.dataTask = [NewNetManager getNewWithPage:_page Completionhandle:^(newModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        completionHandle (error);
    }];
}

@end

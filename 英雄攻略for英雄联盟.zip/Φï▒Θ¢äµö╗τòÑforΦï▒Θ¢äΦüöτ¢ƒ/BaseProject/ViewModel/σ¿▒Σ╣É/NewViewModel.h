//
//  NewViewModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NewNetManager.h"

@interface NewViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;
@property (nonatomic) NSInteger page;

- (NSURL *)srcPhotoForRow : (NSInteger)row; // 图片
- (NSString *)titleForRow : (NSInteger)row; // 标题
- (NSString *)contentForRow : (NSInteger)row; // 详情
- (NSString *)readCountForRow : (NSInteger)row; // 阅读人数
- (NSString *)artidForRow : (NSInteger)row; // ID;
- (NSInteger)hasVideoForRow : (NSInteger)row;  // 视频
@end

//
//  newVideoViewModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "NewVideoNetManager.h"  

@interface newVideoViewModel : BaseViewModel

@property (nonatomic) NSInteger rowNumber;
@property (nonatomic) NSInteger page;

- (NSURL *)srcPhotoForRow : (NSInteger)row;
- (NSString *)titleForRow : (NSInteger)row;
- (NSString *)readCountForRow : (NSInteger)row;
- (NSString *)artIdForRow : (NSInteger)row;

@end

//
//  newVideoViewModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "newVideoViewModel.h"

@implementation newVideoViewModel

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (KDataModel *)newVideoDataFoeRow : (NSInteger)row {
    return self.dataArr[row];
}
- (NSURL *)srcPhotoForRow : (NSInteger)row {
    return [NSURL URLWithString:[self newVideoDataFoeRow:row].photo];
}
- (NSString *)titleForRow : (NSInteger)row {
    return [self newVideoDataFoeRow:row].title;
}
- (NSString *)readCountForRow : (NSInteger)row {
    return [self newVideoDataFoeRow:row].readCount;
}
- (NSString *)artIdForRow:(NSInteger)row {
    return [self newVideoDataFoeRow:row].artId;
}
//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle {
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle {
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle {
    self.dataTask = [NewVideoNetManager getNewVideoPage:_page Completionhandle:^(NewVideoModel *model, NSError *error) {
        if (_page == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        completionHandle (error);
    }];
}


@end

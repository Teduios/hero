//
//  heroVideoViewModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "heroVideoViewModel.h"

@implementation heroVideoViewModel

- (instancetype)initWithEnName:(NSString *)enName {
    if (self = [super init]) {
        _enName = enName;
    }
    return self;
}

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (heroVideoModel *)heroVideoDataForRow : (NSInteger)row {
    return self.dataArr[row];
}
- (NSString *)titlrForRow : (NSInteger)row {
    return [self heroVideoDataForRow:row].title;
}
- (NSURL *)coverURLForRow : (NSInteger)row {
    NSString *cover = [self heroVideoDataForRow:row].cover_url;
    return [NSURL URLWithString:cover];
}
- (NSString *)uploadTimeForRow : (NSInteger)row {
    NSString *upload = [self heroVideoDataForRow:row].upload_time;
    NSArray *array = [upload componentsSeparatedByString:@" "];
    return array[1];
}  // 时长
- (NSString *)vidForRow:(NSInteger)row {
    return [self heroVideoDataForRow:row].vid;
}

//获取更多
- (void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle {
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle {
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle {
    self.dataTask = [allHeroesNetManager getHeroVideoPage:_page tag:_enName Completionhandle:^(heroVideoModel *model, NSError *error) {
        if (_page == 0) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:(NSArray *)model];
        completionHandle (error);
    }];
}

@end

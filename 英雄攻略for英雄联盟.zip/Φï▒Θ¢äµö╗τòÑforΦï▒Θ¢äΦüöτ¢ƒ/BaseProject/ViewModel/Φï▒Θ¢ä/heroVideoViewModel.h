//
//  heroVideoViewModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "allHeroesNetManager.h"

@interface heroVideoViewModel : BaseViewModel

- (instancetype)initWithEnName : (NSString *)enName;
@property (nonatomic , strong) NSString *enName;
@property (nonatomic) NSInteger page;

@property (nonatomic) NSInteger rowNumber;

- (NSString *)titlrForRow : (NSInteger)row;
- (NSURL *)coverURLForRow : (NSInteger)row;
- (NSString *)uploadTimeForRow : (NSInteger)row;  // 时长
- (NSString *)vidForRow : (NSInteger)row; // 视频地址

@end

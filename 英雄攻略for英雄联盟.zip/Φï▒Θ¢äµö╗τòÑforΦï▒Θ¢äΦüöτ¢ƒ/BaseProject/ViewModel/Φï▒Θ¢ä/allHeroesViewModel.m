//
//  allHeroesViewModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "allHeroesViewModel.h"

@implementation allHeroesViewModel

- (NSInteger)rowNumber {
    return self.dataArr.count;
}

- (AllModel *)allHeroesForRow : (NSInteger)row {
    return self.dataArr[row];
}
- (NSURL *)iconURLForRow : (NSInteger)row {
    NSString *name = [self allHeroesForRow:row].enName;
    NSString *strName = [NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",name];
    return [NSURL URLWithString:strName];
}
- (NSString *)nameForRow : (NSInteger)row {
    return [self allHeroesForRow:row].title;
}
- (NSString *)cnNameForRow : (NSInteger)row {
    return [self allHeroesForRow:row].cnName;
}
- (NSString *)ratingForRow : (NSInteger)row {
    return [self allHeroesForRow:row].rating;
}
- (NSString *)priceForRow : (NSInteger)row {
    return [self allHeroesForRow:row].price;
}
- (NSString *)enNameForRow:(NSInteger)row {
    return [self allHeroesForRow:row].enName;
}
//刷新
- (void)refreshDataCompletionHandle:(CompletionHandle)completionHandle {
    [self getDataFromNetCompleteHandle:completionHandle];
}
//获取数据
- (void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle {
    self.dataTask = [allHeroesNetManager getAllHeroesCompletionhandle:^(allHeroesModel *model, NSError *error) {
        [self.dataArr removeAllObjects];
        
        [self.dataArr addObjectsFromArray:model.all];
        completionHandle (error);
    }];
}
@end

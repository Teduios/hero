//
//  allHeroesViewModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "allHeroesNetManager.h"

@interface allHeroesViewModel : BaseViewModel<BaseViewModelDelegate>

@property (nonatomic) NSInteger rowNumber;

- (NSURL *)iconURLForRow : (NSInteger)row;  // 头像
- (NSString *)nameForRow : (NSInteger)row;  // 称号
- (NSString *)cnNameForRow : (NSInteger)row; //  中文名
- (NSString *)ratingForRow : (NSInteger)row; // 难度系数
- (NSString *)priceForRow : (NSInteger)row; // 价格
- (NSString *)enNameForRow : (NSInteger)row; // 英文名



@end

//
//  NewNetManager.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewNetManager.h"

// 手机版本号
#define kOSType  [UIDevice currentDevice].systemVersion

// ?action=l&newsTag=headlineNews&p=1&v=152&OSType=iOS9.1&versionName=2.4.2
#define newPath  @"http://box.dwstatic.com/apiNewsList.php"

// ?action=d&newsId=26950&v=152&OSType=iOS9.1&versionName=2.4.2


@implementation NewNetManager

+ (id)getNewWithPage:(NSInteger)page Completionhandle:(void (^)(newModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"l",
                          @"newsTag":@"headlineNews",
                          @"p":@(page),
                          @"v":@"152",
                          @"OSType":[@"iOS"stringByAppendingString:kOSType],
                          @"versionName":@"2.4.2"};
    return [self GET:newPath parameters:dic completionHandler:^(newModel *responseObj, NSError *error) {
        complete ([newModel objectWithKeyValues:responseObj],error);
    }];
}

+ (id)getnewWithNewsId:(NSString *)newsId Completionhandle:(void (^)(newDataModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"d",
                          @"newsId":newsId,
                          @"v":@"152",
                          @"OSType":[@"iOS"stringByAppendingString:kOSType],
                          @"versionName":@"2.4.2"};
    return [self GET:newPath parameters:dic completionHandler:^(newDataModel *responseObj, NSError *error) {
        complete ([newDataModel objectWithKeyValues:responseObj],error);
    }];
}

@end

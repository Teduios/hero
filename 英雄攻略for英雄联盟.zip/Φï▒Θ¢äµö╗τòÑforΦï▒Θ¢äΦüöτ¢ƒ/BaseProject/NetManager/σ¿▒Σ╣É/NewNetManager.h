//
//  NewNetManager.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "newModel.h"
#import "newDataModel.h"

@interface NewNetManager : BaseNetManager

// http://box.dwstatic.com/apiNewsList.php?action=l&newsTag=headlineNews&p=1&v=152&OSType=iOS9.1&versionName=2.4.2
+ (id)getNewWithPage : (NSInteger)page Completionhandle : (void(^)(newModel *model , NSError *error))complete;

// http://box.dwstatic.com/apiNewsList.php?action=d&newsId=26950&v=152&OSType=iOS9.1&versionName=2.4.2
+ (id)getnewWithNewsId : (NSString *)newsId Completionhandle : (void(^)(newDataModel *model , NSError *error))complete;

@end

//
//  allHeroesNetManager.m
//  BaseProject
//
//  Created by ios－33 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "allHeroesNetManager.h"

// 手机版本号
#define kOSType  [UIDevice currentDevice].systemVersion

// 英雄
#define heroPath @"http://lolbox.duowan.com/phone/apiHeroes.php"

// 视频
// http://box.dwstatic.com/apiVideoesNormalDuowan.php
// ?action=l&p=1&v=140&OSType=iOS9.1&tag=Braum&src=letv
#define videos   @"http://box.dwstatic.com/apiVideoesNormalDuowan.php"

// ?action=f&vid=185466
#define video   @"http://box.dwstatic.com/apiVideoesNormalDuowan.php"
@implementation allHeroesNetManager

+ (id)getAllHeroesCompletionhandle:(void (^)(allHeroesModel *, NSError *))complete {
    NSDictionary *dic = @{@"type":@"all",
                          @"v":@140,
                          @"OSType":[@"iOS"stringByAppendingString:kOSType]
                          };
    return [self GET:heroPath parameters:dic completionHandler:^(allHeroesModel *responseObj, NSError *error) {
        complete ([allHeroesModel objectWithKeyValues:responseObj],error);
    }];
    
}

+ (id)getHeroVideoPage:(NSInteger)page tag:(NSString *)enName Completionhandle:(void (^)(heroVideoModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"l",
                          @"p":@(page),
                          @"v":@"140",
                          @"OSType":[@"iOS"stringByAppendingString:kOSType],
                          @"tag":enName,
                          @"src":@"letv"};
    return [self GET:videos parameters:dic completionHandler:^(id responseObj, NSError *error) {
        complete ([[heroVideoModel objectArrayWithKeyValuesArray:responseObj]copy],error);
    }];
}

+ (id)getVideoVid:(NSString *)vid Completionhandle:(void (^)(videoModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"f",
                          @"vid":vid};
    return [self GET:video parameters:dic completionHandler:^(id responseObj, NSError *error) {
        complete ([videoModel objectWithKeyValues:responseObj],error);
    }];
}




@end

//
//  allHeroesNetManager.h
//  BaseProject
//
//  Created by ios－33 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "allHeroesModel.h"
#import "heroVideoModel.h"
#import "videoModel.h"

@interface allHeroesNetManager : BaseNetManager


// http://lolbox.duowan.com/phone/apiHeroes.php?type=all&v=140&OSType=iOS9.1
// 英雄信息
+ (id)getAllHeroesCompletionhandle : (void(^)(allHeroesModel *model , NSError *error))complete;

// http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=l&p=1&v=152&OSType=iOS9.1&tag=Ekko&src=letv
+ (id)getHeroVideoPage:(NSInteger)page tag:(NSString *)enName Completionhandle : (void(^)(heroVideoModel *model , NSError *error))complete;
// http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=f&vid=185466
+ (id)getVideoVid : (NSString *)vid Completionhandle : (void(^)(videoModel *model , NSError *error))complete;
@end

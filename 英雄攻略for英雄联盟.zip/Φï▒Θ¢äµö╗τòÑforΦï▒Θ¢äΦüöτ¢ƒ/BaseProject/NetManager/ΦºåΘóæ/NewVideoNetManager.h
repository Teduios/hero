//
//  NewVideoNetManager.h
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "NewVideoModel.h"
#import "NewVideosldModel.h"
#import "videoLookModel.h"

@interface NewVideoNetManager : BaseNetManager

// http://box.dwstatic.com/apiNewsList.php?action=l&newsTag=newsVideo&p=1&v=152&OSType=iOS9.1&versionName=2.4.2
+ (id)getNewVideoPage : (NSInteger)page Completionhandle : (void(^)(NewVideoModel *model , NSError *error))complete;

// http://box.dwstatic.com/apiNewsList.php?action=d&newsId=26990&v=152&OSType=iOS9.1&versionName=2.4.2
+ (id)getNewVideoNewsId : (NSString *)newsId Completionhandle : (void(^)(NewVideosldModel *model , NSError *error))complete;

// http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=f&vid=190085
+ (id)getVideoLookVid : (NSString *)vid Completionhandle : (void(^)(videoLookModel *model , NSError *error))complete;

@end

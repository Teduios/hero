//
//  NewVideoNetManager.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewVideoNetManager.h"

// 手机版本号
#define kOSType  [UIDevice currentDevice].systemVersion
// ?action=l&newsTag=newsVideo&p=1&v=152&OSType=iOS9.1&versionName=2.4.2
#define videoPath  @"http://box.dwstatic.com/apiNewsList.php"

// ?action=d&newsId=26990&v=152&OSType=iOS9.1&versionName=2.4.2

// ?action=f&vid=190085
#define lookVideo  @"http://box.dwstatic.com/apiVideoesNormalDuowan.php"

@implementation NewVideoNetManager
+ (id)getNewVideoPage:(NSInteger)page Completionhandle:(void (^)(NewVideoModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"l",
                          @"newsTag":@"newsVideo",
                          @"p":@(page),
                          @"v":@"152",
                          @"OSType":[@"iOS"stringByAppendingString:kOSType],
                          @"versionName":@"2.4.2"};
    return [self GET:videoPath parameters:dic completionHandler:^(NewVideoModel *responseObj, NSError *error) {
        complete ([NewVideoModel objectWithKeyValues:responseObj],error);
    }];
}

+ (id)getNewVideoNewsId:(NSString *)newsId Completionhandle:(void (^)(NewVideosldModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"d",
                          @"newsId":newsId,
                          @"v":@"152",
                          @"OSType":[@"iOS"stringByAppendingString:kOSType],
                          @"versionName":@"2.4.2",};
    return [self GET:videoPath parameters:dic completionHandler:^(NewVideosldModel *responseObj, NSError *error) {
        complete ([NewVideosldModel objectWithKeyValues:responseObj],error);
    }];
}

+ (id)getVideoLookVid:(NSString *)vid Completionhandle:(void (^)(videoLookModel *, NSError *))complete {
    NSDictionary *dic = @{@"action":@"f",
                          @"vid":vid};
    return [self GET:lookVideo parameters:dic completionHandler:^(videoLookModel *responseObj, NSError *error) {
        complete ([videoLookModel objectWithKeyValues:responseObj],error);
    }];
}
@end

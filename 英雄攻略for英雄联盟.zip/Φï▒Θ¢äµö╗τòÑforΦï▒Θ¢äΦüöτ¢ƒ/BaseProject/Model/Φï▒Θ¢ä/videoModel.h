//
//  videoModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class ResultModel,ItemsModel,ThreeMdoel,TranscodeModel,OneModel;
@interface videoModel : BaseModel

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) ResultModel *result;

@property (nonatomic, assign) NSInteger code;

@end
@interface ResultModel : NSObject

@property (nonatomic, strong) ItemsModel *items;

@property (nonatomic, copy) NSString *cover;

@end

@interface ItemsModel : NSObject

@property (nonatomic, strong) ThreeMdoel *A350;

@property (nonatomic, strong) OneModel *A1000;

@end

@interface ThreeMdoel : NSObject

@property (nonatomic, strong) TranscodeModel *transcode;

@property (nonatomic, copy) NSString *video_name;

@property (nonatomic, copy) NSString *transcode_id;

@property (nonatomic, copy) NSString *vid;

@property (nonatomic, copy) NSString *definition;

@end

@interface OneModel : NSObject

@property (nonatomic, strong) TranscodeModel *transcode;

@property (nonatomic, copy) NSString *video_name;

@property (nonatomic, copy) NSString *transcode_id;

@property (nonatomic, copy) NSString *vid;

@property (nonatomic, copy) NSString *definition;

@end

@interface TranscodeModel : NSObject

@property (nonatomic, copy) NSString *height;

@property (nonatomic, strong) NSArray<NSString *> *urls;

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *transcode_id;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *video_name;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *path;

@end




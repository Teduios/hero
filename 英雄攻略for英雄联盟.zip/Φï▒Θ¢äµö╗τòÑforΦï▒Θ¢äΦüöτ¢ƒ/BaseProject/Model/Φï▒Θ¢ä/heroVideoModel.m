//
//  heroVideoModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "heroVideoModel.h"

@implementation heroVideoModel

@end



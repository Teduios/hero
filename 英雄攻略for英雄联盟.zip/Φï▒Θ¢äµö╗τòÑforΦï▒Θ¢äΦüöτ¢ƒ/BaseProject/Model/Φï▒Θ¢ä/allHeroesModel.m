//
//  allHeroesModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "allHeroesModel.h"

@implementation allHeroesModel


+ (NSDictionary *)objectClassInArray{
    return @{@"all" : [AllModel class]};
}
@end
@implementation AllModel

@end



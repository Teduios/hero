//
//  videoModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "videoModel.h"

@implementation videoModel

@end
@implementation ResultModel

@end


@implementation ItemsModel
//A350
//A1000
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"A350":@"350",
             @"A1000":@"A1000"};
}
@end


@implementation ThreeMdoel

@end


@implementation TranscodeModel

@end


@implementation OneModel

@end




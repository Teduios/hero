//
//  NewVideosldModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewVideosldModel.h"

@implementation NewVideosldModel
+ (NSDictionary *)objectClassInArray {
    return @{@"data":[VDataModel class]};
}
@end

// VDataModel , videoModel
@implementation VDataModel
+ (NSDictionary *)objectClassInArray {
    return @{@"video":[VideoModel class]};
}
@end

@implementation VideoModel

@end

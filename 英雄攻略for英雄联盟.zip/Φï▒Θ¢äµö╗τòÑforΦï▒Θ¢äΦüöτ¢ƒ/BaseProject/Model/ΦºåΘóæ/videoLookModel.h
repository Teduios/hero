//
//  videoLookModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class NResultModel,NItemsModel,A350Model,NTranscodeModel,A1000Model,A1300Model;
@interface videoLookModel : BaseModel

@property (nonatomic, copy) NSString *message;

@property (nonatomic, strong) NResultModel *result;

@property (nonatomic, assign) NSInteger code;

@end
@interface NResultModel : NSObject

@property (nonatomic, strong) NItemsModel *items;

@property (nonatomic, copy) NSString *cover;

@end

@interface NItemsModel : NSObject

@property (nonatomic, strong) A350Model *V350;

@property (nonatomic, strong) A1000Model *V1000;

@property (nonatomic, strong) A1300Model *V1300;

@end

@interface A350Model : NSObject

@end


@interface A1000Model : NSObject

@property (nonatomic, strong) NTranscodeModel *transcode;

@property (nonatomic, copy) NSString *video_name;

@property (nonatomic, copy) NSString *transcode_id;

@property (nonatomic, copy) NSString *vid;

@property (nonatomic, copy) NSString *definition;

@end

@interface NTranscodeModel : NSObject

@property (nonatomic, copy) NSString *height;

@property (nonatomic, strong) NSArray<NSString *> *urls;

@property (nonatomic, copy) NSString *width;

@property (nonatomic, copy) NSString *transcode_id;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *video_name;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *path;

@end

@interface A1300Model : NSObject

@end




//
//  videoLookModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "videoLookModel.h"

@implementation videoLookModel
//ResultModel *result;
+ (NSDictionary *)objectClassInArray {
    return @{@"result":[NResultModel class]};
}
@end
@implementation NResultModel
// ItemsModel *items
+ (NSDictionary *)objectClassInArray {
    return  @{@"items":[NItemsModel class]};
}
@end

@implementation NItemsModel
/**
 A350Model *V350
 A1000Model *V1000
 A1300Model *V1300
 */
+ (NSDictionary *)objectClassInArray {
    return @{@"V350":[A350Model class],
             @"V1000":[A1000Model class],
             @"V1300":[A1300Model class]};
}
+ (NSDictionary *)replacedKeyFromPropertyName {
    return  @{@"V350":@"350",
              @"V1000":@"1000",
              @"V1300":@"1300"};
}
@end

@implementation A350Model

@end

@implementation NTranscodeModel

@end

@implementation A1000Model
// TranscodeModel *transcode
+ (NSDictionary *)objectClassInArray {
    return @{@"transcode":[NTranscodeModel class]};
}
@end

@implementation A1300Model

@end





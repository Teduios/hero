//
//  NewVideosldModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class VDataModel , VideoModel;

@interface NewVideosldModel : BaseModel
@property (nonatomic , copy) NSString *msg;
@property (nonatomic , copy) NSNumber *rs;
@property (nonatomic , strong) VDataModel *data;
@end

@interface VDataModel : BaseModel
@property (nonatomic , strong) NSArray<VideoModel *> *video;
@end

@interface VideoModel : BaseModel
@property (nonatomic , strong) NSString *uu;
@property (nonatomic , strong) NSString *vid;
@end

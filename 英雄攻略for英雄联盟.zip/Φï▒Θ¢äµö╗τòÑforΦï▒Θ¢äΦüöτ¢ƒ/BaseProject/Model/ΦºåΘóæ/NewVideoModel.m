//
//  NewVideoModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "NewVideoModel.h"

@implementation NewVideoModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [KDataModel class]};
}
@end
@implementation KDataModel
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}
@end



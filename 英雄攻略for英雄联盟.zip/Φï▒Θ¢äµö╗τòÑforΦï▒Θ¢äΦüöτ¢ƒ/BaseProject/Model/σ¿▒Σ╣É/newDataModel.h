//
//  newDataModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class NDataModel , commentHotModel , photoModel;

@interface newDataModel : BaseModel
@property (nonatomic , copy) NSString *msg;
@property (nonatomic , copy) NSNumber *rs;
@property (nonatomic , strong) NDataModel *data;
@end

@interface NDataModel : BaseModel
@property (nonatomic , strong) NSString *art_id;
@property (nonatomic , strong) NSString *cai;
@property (nonatomic , strong) NSString *cmsld;
@property (nonatomic , strong) NSArray<commentHotModel *> *commentHot; // 评论
@property (nonatomic , strong) NSString *commentId;
@property (nonatomic , strong) NSString *commentSum;
@property (nonatomic , strong) NSString *commentUrl;
@property (nonatomic , strong) NSString *content;  // 内容
@property (nonatomic , strong) NSString *digest;
@property (nonatomic , strong) NSString *ding;
@property (nonatomic , strong) photoModel *photo;
@property (nonatomic , strong) NSString *pub_time;
@property (nonatomic , strong) NSString *read_count;
@property (nonatomic , strong) NSString *smallIcon;
@property (nonatomic , strong) NSString *srcPhoto;
@property (nonatomic , strong) NSString *title;
@property (nonatomic , strong) NSString *video;
@property (nonatomic , strong) NSString *ymzId;
@end

@interface commentHotModel : BaseModel

@end

@interface photoModel : BaseModel
@property (nonatomic , strong) NSArray *big;
@end



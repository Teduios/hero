//
//  newDataModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "newDataModel.h"

// DataModel , commentHotModel , photoModel;

@implementation newDataModel
+ (NSDictionary *)objectClassInArray {
    return @{@"data":[NDataModel class]};
}
@end

@implementation NDataModel

+ (NSDictionary *)objectClassInArray {
    return @{@"commentHot":[commentHotModel class],
             @"photo":[photoModel class]};
}

@end

@implementation commentHotModel

@end

@implementation photoModel

@end


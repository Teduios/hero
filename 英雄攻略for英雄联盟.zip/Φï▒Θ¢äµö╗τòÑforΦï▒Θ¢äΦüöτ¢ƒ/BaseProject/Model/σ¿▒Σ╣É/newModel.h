//
//  newModel.h
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@class DataModel,HeaderlineModel;
@interface newModel : BaseModel

@property (nonatomic, assign) NSInteger pageSize;

@property (nonatomic, strong) NSArray<DataModel *> *data;

@property (nonatomic, copy) NSString *order;

@property (nonatomic, strong) NSArray<HeaderlineModel *> *headerline;

@property (nonatomic, copy) NSString *totalRecord;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, assign) BOOL rs;

@property (nonatomic, assign) NSInteger totalPage;

@property (nonatomic, assign) NSInteger pageNum;

@end
@interface DataModel : NSObject

@property (nonatomic, copy) NSString *ID;//id;

@property (nonatomic, copy) NSString *commentUrl;

@property (nonatomic, copy) NSString *ymz_id;

@property (nonatomic, copy) NSString *destUrl;

@property (nonatomic, copy) NSString *time;

@property (nonatomic, copy) NSString *weight;

@property (nonatomic, copy) NSString *commentSum;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *srcPhoto;

@property (nonatomic, copy) NSString *readCount;

@property (nonatomic, copy) NSString *artId;

@property (nonatomic, assign) NSInteger hasVideo;

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, copy) NSString *content;

@end

@interface HeaderlineModel : NSObject

@property (nonatomic, copy) NSString *weight;

@property (nonatomic, copy) NSString *commentUrl;

@property (nonatomic, copy) NSString *ID;//id;

@property (nonatomic, copy) NSString *destUrl;

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, copy) NSString *artId;

@property (nonatomic, copy) NSString *commentSum;

@end


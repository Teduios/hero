//
//  newModel.m
//  BaseProject
//
//  Created by ios－33 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "newModel.h"

@implementation newModel


+ (NSDictionary *)objectClassInArray{
    return @{@"data" : [DataModel class], @"headerline" : [HeaderlineModel class]};
}
@end
@implementation DataModel
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}
@end
@implementation HeaderlineModel
+ (NSDictionary *)replacedKeyFromPropertyName {
    return @{@"ID":@"id"};
}
@end


